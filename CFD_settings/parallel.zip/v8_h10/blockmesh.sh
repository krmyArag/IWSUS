echo Mesh-generator begins!
rm -rf ./system/blockMeshDict
echo "/*--------------------------------*- C++ -*----------------------------------*\\
  =========                 |
  \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\\\    /   O peration     | Website:  https://openfoam.org
    \\\\  /    A nd           | Version:  7
     \\\\/     M anipulation  |
\\*---------------------------------------------------------------------------*/
FoamFile
{
    version     2.0;
    format      ascii;
    class       dictionary;
    object      blockMeshDict;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
" >> ./system/blockMeshDict
echo "convertToMeters 1;" >> ./system/blockMeshDict
echo "" >> ./system/blockMeshDict
# Vertice
echo Generating vertices ...
vx=(0 35 40 60 65 100)
vy=(0 30 70 100)
#v=(0 40 80 100 140 160 200 220 260 300)
buildx=5
buildy=40
street=20
edgx=35
edgy=30
height=10
let hh=10
zmax=60
h[0]=0
h[1]=$hh
h[2]=$zmax
let above=(zmax-hh)
echo "vertices" >> ./system/blockMeshDict
echo "(" >> ./system/blockMeshDict
for ((k = 0; k <= 2; k++))
do
    for ((j = 0; j <= 5; j++))
    do
        for ((i = 0; i <= 3; i++))
        do
            let inum=k*24+j*4+i
            echo $inum
            let v1=${vx[j]}
            let v2=${vy[i]}
            let v3=${h[k]}
            echo "    ($v1 $v2 $v3) //$inum " >> ./system/blockMeshDict
        done
    done
done
echo "); " >> ./system/blockMeshDict
echo "" >> ./system/blockMeshDict
echo Vertices Done!

#blocks
echo Generating blocks...
echo "blocks" >> ./system/blockMeshDict
echo "(" >> ./system/blockMeshDict
id=0
for ((j=0; j<=3; j++))
do
    case $j in
        0 | 2)
            for ((i=0; i<=4; i++))
            do
                let inum=i*4+j
#                echo $inum
                case $i in
                    0 | 4)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($edgx $edgy $height) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    1 | 3)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($buildx $edgy $height) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    2)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($street $edgy $height) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                   ;;
                esac
            done
        ;;
        1)
            for ((i=0; i<=5; i++))
            do
                let inum=i*4+j
#                echo $inum
                case $i in
                    0 | 4)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($edgx $buildy $height) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
#                    1 | 3)
#                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
#$[inum+28] $[inum+29] $[inum+25]) ($buildx $buildy $height) simpleGrading (1 1 1) //b$id
#                        " >> ./system/blockMeshDict
#                    ;;
                    2)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($street $buildy $height) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                esac                        
            done
        ;;
    esac
done

for ((j=0; j<=3; j++))
do
    case $j in
        0 | 2)
            for ((i=0; i<=4; i++))
            do
                let inum=i*4+j+24
#                echo $inum
                case $i in
                    0 | 4)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($edgx $edgy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    1 | 3)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($buildx $edgy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    2)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($street $edgy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                esac
            done
            ;;
        1)
            for ((i=0; i<=5; i++))
            do
                let inum=i*4+j+24
#                echo $inum
                case $i in
                    0 | 4)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($edgx $buildy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    1 | 3)
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($buildx $buildy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                    ;;
                    2 )
                        echo "    hex (${inum} $[inum+4] $[inum+5] $[inum+1] $[inum+24] \
$[inum+28] $[inum+29] $[inum+25]) ($street $buildy $above) simpleGrading (1 1 1) //b$id
                        " >> ./system/blockMeshDict
                        let id=id+1
                ;;
                esac                        
            done
            ;;
    esac
done

echo ");" >> ./system/blockMeshDict
echo " " >> ./system/blockMeshDict
echo Blocks done!

#Edges
echo Generating edges ...
echo "edges" >> ./system/blockMeshDict
echo "(" >> ./system/blockMeshDict
echo ");" >> ./system/blockMeshDict
echo " " >> ./system/blockMeshDict
echo Edges done!

#Boundary
echo Generating boundaries ...
echo "boundary" >> ./system/blockMeshDict
echo "(" >> ./system/blockMeshDict
echo "   front" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type patch;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((k=0; k<=1; k++))
do
    for ((j=0; j<=2;j++))
    do
        let inum=k*24+j
        echo "            (${inum} $[inum+24] $[inum+25] $[inum+1])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    back" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type patch;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((k=0;k<=1;k++))
do
    for ((j=0;j<=2;j++))
    do
        let inum=k*24+j+20
        echo "            ($inum $[inum+24] $[inum+25] $[inum+1])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    right" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type patch;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((k=0;k<=1;k++))
do
    for ((i=0;i<=4;i++))
    do
        let inum=k*24+i*4+3
        echo "            ($inum $[inum+4] $[inum+28] $[inum+24])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    left" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type patch;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((k=0;k<=1;k++))
do
    for ((i=0;i<=4;i++))
    do
        let inum=k*24+i*4
        echo "            ($inum $[inum+4] $[inum+28] $[inum+24])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    up" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type patch;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((j=0;j<=2;j++))
do
    for ((i=0;i<=4;i++))
    do
        let inum=48+i*4+j
        echo "            ($inum $[inum+4] $[inum+5] $[inum+1])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    ground" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type wall;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
for ((j=0;j<=2;j++))
do
    for ((i=0;i<=4;i++))
    do
        let inum=i*4+j
        if [ $(($i%2)) -eq 1 ] && [ $(($j%2)) -eq 1 ] ; then
            continue
        fi
        echo "            ($inum $[inum+4] $[inum+5] $[inum+1])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict

echo "    wall" >> ./system/blockMeshDict
echo "    {" >> ./system/blockMeshDict
echo "        type wall;" >> ./system/blockMeshDict
echo "        faces" >> ./system/blockMeshDict
echo "        (" >> ./system/blockMeshDict
# front and back walls
for ((j=1;j<=2;j++))
do
    for ((i=1;i<=3;i+=2))
    do
        let inum=i*4+j
        echo "            ($inum $[inum+4] $[inum+28] $[inum+24])" >> ./system/blockMeshDict
    done
done
# left and right walls
for ((j=1;j<2;j++))
do
    for ((i=1;i<=4;i++))
    do
        let inum=i*4+j
        echo "            ($inum $[inum+24] $[inum+25] $[inum+1])" >> ./system/blockMeshDict
    done
done
# top walls
for ((j=1;j<2;j+=2))
do
    for ((i=1;i<=4;i+=2))
    do
        let inum=i*4+j+24
        echo "            ($inum $[inum+4] $[inum+5] $[inum+1])" >> ./system/blockMeshDict
    done
done
echo "        );" >> ./system/blockMeshDict
echo "    }" >> ./system/blockMeshDict
echo ");" >> ./system/blockMeshDict
echo "" >> ./system/blockMeshDict
echo Boundaries done!

#MergerPatchPairs
echo "mergePatchPairs" >> ./system/blockMeshDict
echo "(" >> ./system/blockMeshDict
echo ");" >> ./system/blockMeshDict
echo "
// ************************************************************************* //
" >> ./system/blockMeshDict

echo Mesh-generator complete!
